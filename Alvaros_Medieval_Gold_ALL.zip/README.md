# ✦ Alvaros Medieval Gold Resource Pack ✦

**Created by:** Alvaros  
**Version:** 1.0.0  
**Minecraft:** 1.20.x / 1.21.x  
**Resolution:** 16x16 Vanilla Style  

---

## 📖 About

**Alvaros Medieval Gold** transforms your Minecraft world into a rich medieval kingdom with golden tones and dark atmospheric textures. Every block has been carefully crafted to give a premium fantasy feel.

## 🎨 Custom Textures Included

- ⛏️ Stone Bricks — with gold veins
- 🟡 Gold Block — polished & shiny
- 🌿 Grass — warm golden-green tones
- 🪨 Cobblestone — gold-tinted stone
- 🪵 Dark Oak Planks — rich dark wood
- 🏜️ Sand — warm golden desert
- ⚙️ Iron Block — polished silver armor feel
- 💎 Diamond Block — teal medieval gem

---

## 🔧 Installation

1. Download the `.zip` file
2. Open Minecraft → Options → Resource Packs
3. Click **Open Pack Folder**
4. Drop the `.zip` inside
5. Activate and enjoy!

---

## 📜 License

© 2024 Alvaros. All rights reserved.  
Do not reupload or redistribute without permission.
